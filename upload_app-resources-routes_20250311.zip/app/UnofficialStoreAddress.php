<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UnofficialStoreAddress extends Model
{
    use SoftDeletes;
}
