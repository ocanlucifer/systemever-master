<?php
return [
    'home.lembut' => 'SOFT',
]
?>