<?php
return [
    'home.lembut' => 'LEMBUT',
]
?>