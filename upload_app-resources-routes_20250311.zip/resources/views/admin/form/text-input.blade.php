<div class="">
    <label for="sub_title">{{$label}}</label>
    <div class="input-group">
        <input class="form-control w-100" placeholder="{{$label}}" id="{{$name}}" name="{{$name}}">
        <span class="input-group-btn">
            <button class="btn btn-primary" type="button">
            <i class="fa fa-save"></i>
            </button>
        </span>
    </div>
</div>