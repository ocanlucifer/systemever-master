<div class="form-group row" style="padding-top:5px;">
    <label class="control-label col-xs-2" style="padding-top:5px; text-align:right">{{$label}}<span class="text-danger">*</span></label>
    <div class="col-sm-9">
        <textarea class="form-control w-100" placeholder="{{$placeholder}}" name="{{$name}}">{{$value}}</textarea>
    </div>
</div>