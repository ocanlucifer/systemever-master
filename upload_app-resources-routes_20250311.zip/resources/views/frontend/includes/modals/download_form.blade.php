<div class="modal modal-form fade" id="modal-download-form" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog modal-dialog-top m-0 m-md-auto" role="document">
      <div class="modal-content">
        <div class="modal-header border-bottom-0 pb-0">
          <div class="modal-title pt-4 mt-lg-2 mt-md-2 mt-0 pl-lg-4 pl-md-4 pl-0 ml-2">
                <h5>{{ stringlang("Download Brochure", "Unduh Brosur") }}</h5>
                <h3>Upgrade Your Business with <br class="d-lg-block d-md-block d-none"> SystemEver & Get Exclusive <br class="d-lg-block d-md-block d-none"> Benefit!</h3>
          </div>
          <button type="button" class="close btn-close-modal" data-dismiss="modal" aria-label="Close">
            <img src="{{ asset('assets/img/close-modal.svg') }}" alt="">
          </button>
        </div>
        <form action="">
            <div class="modal-body pb-0 px-lg-5 px-md-5 px-4">
              <div class="form-group">
                  <div class="row">
                      <div class="col-md-6 col-sm-12 col-12 d-lg-block d-md-block d-sm-flex d-flex align-items-center justify-content-start mb-lg-0 mb-md-0 mb-3">
                          <div class="label-field">{{ stringlang('Name', 'Nama') }}</div>
                          <input type="text" name="nama" class="form-control txt-form" placeholder="{{ stringlang('Insert your name', 'Masukkan nama anda') }}" required>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-12 col-12 d-lg-block d-md-block d-sm-flex d-flex align-items-center justify-content-start">
                        <div class="label-field">Email</div>
                        <input type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" name="email" class="form-control txt-form" placeholder="{{ stringlang('Insert your email', 'Masukkan email anda') }}" required>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                        <input type="hidden" name="from" value="{{ \URL::full() }}">
                        <div class="mt-3">
                            <div class="g-recaptcha" data-sitekey="{{ env('RECAPTCHA_CLIENT_KEY') }}"></div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
            <div class="modal-footer border-top-0 d-block mb-5">
                <div class="row d-flex justify-content-center">
                    <div class="col-lg-8 col-md-8 col-12"><button type="submit" class="btn btn-white-orange w-100 btn-submit-modal">{{ stringlang('Submit', 'Kirim') }}</button></div>
                </div>
            </div>
        </form>
      </div>
    </div>
</div>