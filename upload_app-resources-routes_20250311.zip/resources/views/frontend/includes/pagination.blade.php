<div class="row">
    <div class="col-lg-12 d-flex justify-content-center">
        <ul class="list-unstyled pagination">
            <li class="prev-arrow d-none"><a href=""><img src="{{ asset('assets/img/arrow-right-paging.svg') }}" alt=""></a></li>
            <li class="prev d-none"><a href="">prev</a></li>
            <li class="page"><a href="" class="active">1</a></li>
            <li class="page"><a href="">2</a></li>
            <li class="page"><a href="">3</a></li>
            <li class="page"><a href="">4</a></li>
            <li class="next"><a href="">next</a></li>
            <li class="next-arrow"><a href=""><img src="{{ asset('assets/img/arrow-right-paging.svg') }}" alt=""></a></li>
        </ul>
    </div>
</div>