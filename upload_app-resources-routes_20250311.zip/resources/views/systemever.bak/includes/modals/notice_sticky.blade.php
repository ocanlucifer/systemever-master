<div class="notice-sticky">
    <div class="notice-sticky-wrap">
        <a href="{{ route('get.pages.notice') }}">
            <img src="{{ asset('assets/img/star-calendar.svg') }}" alt="">
        </a>
    </div>
</div>