@extends('systemever/pages/landing/windi', [
'spesifice_page_seo' => 'Home ' . activelang()
])

@section('custom_css')


{{-- <!--@include('systemever/includes/swiper')--> --}}
<!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />-->
{{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/9.4.1/swiper-bundle.min.css"  /> --}}
{{-- <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet"> --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

<style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

    .bc {
        font-family: 'Open Sans';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 19px;
        color: #000000;
        display: flex;
        align-items: center;
    }

    .bc .active {
        color: #009944;
        font-weight: bold;
    }

    /* .section-demo {
        opacity: 0;
    } */

    .page-content {
        margin-top: 0;
    }

    .font-montserrat {
        font-family: 'Montserrat', sans-serif;
    }

    .font-poppins {
        font-family: 'Poppins', sans-serif;
    }

    .font-opensans {
        font-family: 'Open Sans', sans-serif;
    }

    .font-inter {
        font-family: 'Inter', sans-serif;
    }

    .container {
        max-width: 1140px;
        margin: auto;
        padding-left: 20px;
        padding-right: 20px;
    }

    .hsd:hover {
        box-shadow: 0px 4px 20px 0px #00000055;
    }

    .aspect-mod {
        aspect-ratio: 12/11;
    }

    .aspect-mod1 {
        aspect-ratio: 12/8;
    }
    /* Menyembunyikan scrollbar tapi masih bisa di-scroll */
    .tabs-container::-webkit-scrollbar {
    display: none;
    }
    .tabs-container {
        -ms-overflow-style: none;  /* IE and Edge */
        scrollbar-width: none;  /* Firefox */
        display: flex;
        justify-content: center;
        margin-bottom: 5px;
    }
    /* .tabs-container {
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
    } */

    .tabs {
        display: flex;
        gap: 10px;
        width: 80%; /* Batas lebar container */
        font-size: 18px;
    }

    .tab-button {
        flex: 1; /* Membagi ruang secara merata */
        padding: 14px 20px;
        border: none;
        cursor: pointer;
        background-color: #D4F1E4;
        border-radius: 30px;
        transition: background-color 0.3s ease;
        text-align: center;
        white-space: nowrap; /* Mencegah teks pindah baris */
    }

    .tab-button.active {
        background-color: #179244;
        color: white;
    }

    .tab-content-container {
        text-align: center;
        border: none;
    }

    .tab-content {
        display: none;
        padding: 20px;
        /* border: 1px solid #ddd; */
    }

    .tab-content.active {
        display: block;
    }
    .tab-label {
        display: block;
        font-size: 17px;
        color: #179244;
        font-weight: 500;
        font-size: 18px;
        flex: 1; /* Membagi ruang secara merata */
        padding: 10px 20px;
        border: none;
        text-align: center;
        white-space: nowrap; /* Mencegah teks pindah baris */
    }
    /* Styling paragraf penjelasan dengan numbering */
    .description {
        text-align: left;
    }
    .description-box {
        margin: 20px 0;
        font-size: 14px;
        line-height: 1.8;
        color: #333;
    }
    .description-box ol {
        list-style-type: decimal; /* Menampilkan numbering */
        padding-left: 20px;
        text-align: left;
    }

    .description-box li {
        margin-bottom: 10px;
    }

    /* Styling untuk video */
    .video-container {
        position: relative;
        width: 100%;
        padding-bottom: 56.25%; /* Rasio 16:9 (9/16 = 0.5625) */
        height: 0;
        overflow: hidden;
    }

    .video-container iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: block;
        margin: 0 auto;
    }
    .video-container img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: block;
        margin: 0 auto;
    }

    .custom-button {
        font-family: 'Montserrat', sans-serif; /* Sesuai dengan font yang digunakan */
        font-size: 20px; /* Ukuran font */
        padding: 14px 65px; /* Padding agar tombol proporsional */
        border-radius: 50px; /* Agar tetap bulat */
        background-color: white; /* Warna background */
        color: #009944; /* Warna teks */
        font-weight: bold; /* Teks tebal */
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        border: 2px solid #009944; /* Tambahkan border untuk outline */
        transition: all 0.3s ease-in-out; /* Animasi hover */
    }

    .custom-button:hover {
        color: rgb(0, 0, 0);
        background-color: #D4F1E4;
    }

    .table-container {
        /* max-width: 800px; */
        /* margin: auto; */
        padding: 20px;
        text-align: left;
    }
    .custom-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .custom-table th {
        background-color: #107c10; /* Warna hijau seperti gambar */
        color: white;
        padding: 12px;
        font-size: 18px;
        text-align: left;
    }
    .custom-table td {
        padding: 12px;
        /* border-bottom: 1px solid #ddd; */
    }
    .icon-check {
        color: #107c10; /* Warna hijau */
        font-size: 20px;
        margin-right: 10px;
    }
    .bold-text {
        font-weight: bold;
    }

    @media only screen and (max-width: 1024px) {
        .page-content {
            margin-top: 55px;
        }

        .aspect-mod {
            aspect-ratio: 12/8;
        }
        .tabs-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scroll-snap-type: x mandatory; /* Menyediakan efek snap antar tab */
        }

        .tabs {
            display: inline-flex;
            min-width: 600px; /* Memastikan cukup lebar untuk scroll horizontal */
            width: max-content; /* Lebar tab menyesuaikan konten */
            scroll-snap-align: start; /* Setiap tab berhenti di posisi awal */
            font-size: 14px;
        }
        .custom-button {
            font-size: 14px; /* Font lebih besar */
            padding: 7px 50px; /* Padding lebih besar */
        }

        .tab-button {
            flex: 1; /* Membagi ruang secara merata */
            padding: 10px 20px;
            white-space: nowrap; /* Mencegah teks pindah baris */
            border: none;
            cursor: pointer;
            background-color: #D4F1E4;
            border-radius: 30px;
            transition: background-color 0.3s ease;
            text-align: center;
            white-space: nowrap; /* Mencegah teks pindah baris */
            scroll-snap-align: start; /* Snap pada posisi awal */
        }

        .tab-button.active {
            background-color: #179244;
            color: white;
        }

        .tab-content-container {
            text-align: center;
            border: none;
        }

        .tab-content {
            display: none;
            padding: 20px;
            /* border: 1px solid #ddd; */
        }

        .tab-content.active {
            display: block;
        }
        .tab-label {
            font-size: 14px; /* Ukuran label lebih kecil untuk layar kecil */
        }
        /* Styling paragraf penjelasan dengan numbering */
        .description {
            text-align: left;
        }
        .description-box {
            font-size: 14px;
        }
    }

</style>
@endsection
@section('content')

<section class="lg:pt-200px lg:pb-140px pt-20px pb-60px relative">
    <picture class="absolute top-0 left-0 w-full lg:h-700px h-380px">
        <source srcset="{{ asset('assets/fl/home-bg-1.png')}}" media="(min-width: 1024px)" class="w-full h-full object-cover" style="object-position: bottom center;" />
        <img src="{{ asset('assets/fl/home-bg-1-m.png')}}" alt="" class="w-full h-full object-cover" style="object-position: bottom center;" />
    </picture>
    <div class="container relative">
        <div class="flex flex-col lg:flex-row">
            <div class="lg:w-[60%]  mx-auto">
                <p class="font-opensans text-white lg:text-16px lg:mb-0 mb-0 lg:text-left text-center text-11px ">
                    한국 대표 ERP 기업, 영림원소프트랩의 인니 법인,
                </p>
                <h1 class="font-poppins lg:text-37px  lg:leading-12 lg:text-left  lg:mb-5 lg:mt-8 mb-2 leading-7 text-26px font-bold text-white text-center">
                    System Ever <br> Indonesia
                </h1>
                <p class="font-opensans text-white lg:text-16px lg:mb-3 mb-5 lg:text-left text-center text-11px ">
                    {{-- {!! str_replace("#JadiLebihMudah", '<strong>#JadiLebihMudah</strong>', ordefault($meta->banner_subtitle, 'Kelola bisnis <strong>#JadiLebihMudah</strong> dengan SystemEver.')) !!} --}}
                    <strong>모든 업무를 하나로! 통합형 클라우드 ERP </strong>
                </p>
                <p class="font-opensans text-white lg:text-16px lg:mb-2 mb-2 lg:text-left text-center text-11px ">
                    ERP가 필요한 규모가 되었나요?
                </p>
                <p class="font-opensans text-white lg:text-16px lg:mb-2 mb-2 lg:text-left text-center text-11px ">
                    SystemEver Indonesia와 함께 쉽고 빠르게 디지털 전환을 시작하세요​
                </p>
                <p class="font-opensans text-white lg:text-16px lg:mb-4 mb-2 lg:text-left text-center text-11px ">
                    영업, 구매, 회계, 생산까지 하나의 ERP로 완전 통합!
                </p>
                <div class="flex gap-4 justify-center lg:justify-start">
                    <a href="https://wa.me/6281119971017?text=Hello, I want to know more about system ever" target="_blank" class="custom-button">
                        무료 상담 받기
                    </a>
                    {{-- <a href="https://wa.me/6281119971017?text=Hello, I want to know more about system ever" target="_blank" class="font-montserrat inline-flex items-center justify-center lg:h-48px lg:px-70px lg:text-16px text-12px h-28px px-20px rounded-full bg-transparent hover:text-white text-white font-bold border-1 border-white">
                        문의하기 (Whatsapp)
                    </a> --}}
                </div>
            </div>
            <div class="lg:w-[40%] pt-2">
                <div class="lg:h-[372px] lg:w-[550px] w-[72%] aspect-mod1 overflow-hidden flex items-center justify-center mx-auto lg:-mt-10">
                    <video src="{{ ordefault($meta->home_banner, asset('assets/fl/home.mp4')) }}" autoplay muted loop playsinline class=""></video>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="lg:pt-10px lg:pb-50px pt-20px pb-60px relative">
    <div class="container relative">
        <div class="tabs-container">
            <div class="tabs">
                <button class="tab-button active" data-tab="tabSales"><strong>영업관리</strong></button>
                <button class="tab-button" data-tab="tabInventory"><strong>물류관리</strong></button>
                <button class="tab-button" data-tab="tabAccounting"><strong>회계관리</strong></button>
                <button class="tab-button" data-tab="tabPurchase"><strong>구매관리</strong></button>
                <button class="tab-button" data-tab="tabProduction"><strong>생산관리</strong></button>
                <button class="tab-button" data-tab="tabITInventory"><strong>IT Inventory</strong></button>
            </div>
        </div>

        <div class="tab-content-container">
            <div class="tab-content active" id="tabSales">
                @include('systemever/pages/landing/sales')
            </div>
            <div class="tab-content" id="tabInventory">
                @include('systemever/pages/landing/inventory')
            </div>
            <div class="tab-content" id="tabAccounting">
                @include('systemever/pages/landing/accounting')
            </div>
            <div class="tab-content" id="tabPurchase">
                @include('systemever/pages/landing/purchase')
            </div>
            <div class="tab-content" id="tabProduction">
                @include('systemever/pages/landing/production')
            </div>
            <div class="tab-content" id="tabITInventory">
                @include('systemever/pages/landing/it_inventory')
            </div>
        </div>
    </div>
</section>


{{-- @include('systemever/includes/modals/intro') --}}
@endsection

@section('footer')
@include('systemever/pages/landing/footer')
@endsection

@section('custom_js')


<!--<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/9.4.1/swiper-bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>

    var userAgent = navigator.userAgent.toLowerCase();
    var isMac = /mac|iphone|ipad|ipod/.test(userAgent);
    if(isMac){
        $('.page-content section video').css('filter','brightness(.94) hue-rotate(-2deg)')
    }else{
        $('.page-content section video').css('filter','brightness(1.01) hue-rotate(-1deg)')
    }

    document.addEventListener("DOMContentLoaded", function() {
        const tabs = document.querySelectorAll('.tab-button');
        const contents = document.querySelectorAll('.tab-content');

        tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            // Reset active state
            tabs.forEach(btn => btn.classList.remove('active'));
            contents.forEach(content => content.classList.remove('active'));

            // Set active tab and content
            tab.classList.add('active');
            const target = document.getElementById(tab.dataset.tab);
            if (target) {
            target.classList.add('active');
            }
        });
        });
    });
</script>
<style>
    .page-content section .aspect-mod1.overflow-hidden.flex{
        max-width: 270px;
    }
    @media(min-width: 1024px){
        .page-content section .aspect-mod1.overflow-hidden.flex{
            max-width: 550px;
        }
    }
</style>

@endsection
