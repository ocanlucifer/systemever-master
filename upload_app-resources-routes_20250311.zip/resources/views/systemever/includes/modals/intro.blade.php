<div class="mintro d-none" id="modal-intro">
    <div class="mintro-wrap">
        <div class="mintro-content">
            <div class="mintro-close" id="close-intro">
                <div class="mintro-icon mi-icon-close">
                </div>
            </div>
            <div class="mintro-containt">
                <a href="#" id="mintro-link" target="_blank">
                    <img class="mintro-img-one" id="mintro-image" src="{{ asset('assets/img/no-image.jpg') }}" alt="">
                </a>
            </div>
            <div class="mintro-toggle">
                <div class="mintro-check" id="checked-intro">
                </div>
                <div class="mintro-check-label">
                    I don’t want to see this ads anymore
                </div>
            </div>
        </div>  
    </div>
</div>