<div class="modal-notice d-none" id="modal-notice">
    <div class="mn-block mn-action-close">
    </div>
    <div class="mn-wrap">
        <div class="mn-content">
            <div class="mn-close">
                <div class="mintro-icon mi-icon-close-n mn-action-close"></div>
            </div>
            <div class="mn-title" id="mn-title">
                공간의 경계를 허물고, 시간의 경계를 허물고
            </div>
            <div class="mn-desc">
                <div class="mnd-item">
                    <span class="mnd-label">
                        Author
                    </span>
                    <span class="mnd-desc" id="mn-author">
                        Ksystem
                    </span>
                </div>
                <div class="mnd-item">
                    <span class="mnd-label">
                        Date
                    </span>
                    <span class="mnd-desc" id="mn-date">
                        2021-10-15 15:47
                    </span>
                </div>
                <div class="mnd-item">
                    <span class="mnd-label">
                        Views
                    </span>
                    <span class="mnd-desc" id="mn-views">
                        151
                    </span>
                </div>
            </div>
            <div class="mn-image">
                <img id="mn-image" src="{{ asset('assets/img/image-notice.jpg') }}" alt="notice image">
            </div>
        </div>
    </div>
</div>