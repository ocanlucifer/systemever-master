<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<script>
    var path = "{{ asset('') }}";
</script>
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="shortcut icon" href="{{asset('assets/fl/systemever-favicon.png')}}" type="image/x-icon">
<link href="{{ asset('assets/plugins/bootstrap4/css/bootstrap.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/plugins/fontawesome/css/font-awesome.min.css')}}" rel="stylesheet">
<link href="{{ asset('assets/plugins/owl/owl.carousel.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/plugins/hamburger/hamburgers.css') }}" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="{{ asset('assets/css/fonts.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/button-swipe.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="{{ asset('assets/css/custom-checkbox.css') }}">
<link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet" />
<style>.h-30 { height:30px; }</style>
